package com.murach.tempconverter;

import android.os.Bundle;
import android.app.Activity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.widget.TextView.OnEditorActionListener;

import java.text.DecimalFormat;

public class TempConverterActivity extends Activity
implements OnEditorActionListener{

    //define var for widgets
    private EditText fahrenheitEditTExt;
    private TextView celciusTextView;
    private SharedPreferences savedTemp;
    private String fahrenheitString;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_temp_converter);

        fahrenheitEditTExt = (EditText) findViewById(R.id.fahrenheitEditText);
        celciusTextView = (TextView) findViewById(R.id.celciusTextView);

        fahrenheitEditTExt.setOnEditorActionListener(this);

        savedTemp = getSharedPreferences("SavedTemp", MODE_PRIVATE);

	}

    @Override
    public void onPause() {

        // save the instance variables
        SharedPreferences.Editor editor = savedTemp.edit();
        editor.putString("fahrenheit", fahrenheitString);
        editor.commit();

        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();

        // get the instance variables
        fahrenheitString = savedTemp.getString("fahrenheit", "");

        // set the temp on its widget
        fahrenheitEditTExt.setText(fahrenheitString);

        // calculate and display
        convertAndDisplay();

    }

    private void convertAndDisplay(){

        fahrenheitString = fahrenheitEditTExt.getText().toString();
        float f;

        f = Float.parseFloat(fahrenheitString);

        //conversion formula
        float c = (f-32)*5/9;

        //display results
        DecimalFormat df = new DecimalFormat("#.##");
        celciusTextView.setText(df.format(c));

    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

        if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {

            convertAndDisplay();

        }

        return false;

    }

}