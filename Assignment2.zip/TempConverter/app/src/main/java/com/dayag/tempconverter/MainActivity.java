package com.dayag.tempconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    //instance variable
    private EditText fahEditText;
    private TextView convertTextView;
    private String fahToCel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fahEditText = (EditText) findViewById(R.id.fahEditText);
        convertTextView = (TextView) findViewById(R.id.convertTextView);


    }

    //perform convert
    public void convert(View v) {

        fahToCel = fahEditText.getText().toString();
        float degree;

        if (fahEditText.equals("")) {

            degree = 0;

        }

        else {

            degree = Float.parseFloat(fahToCel);

        }

        //conversion formula
        float celDegree = (degree-32)*5/9;

        //display results
        convertTextView.setText(new Double(celDegree).toString());

    }

}
